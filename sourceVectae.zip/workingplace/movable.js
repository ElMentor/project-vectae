$(document).ready(function(){
            $("#movableBox").draggable({ handle: ".deplaceur"});
            $('#movableBox .closer').click(function() {
            	$("#movableBox").hide();
            
            
            });
        });