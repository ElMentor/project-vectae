
<div class="conteneurInput">

<?php
if ( !empty($_POST['email']) AND !empty($_POST['mdp']) AND !empty($_POST['verifmdp']) )
{
    $email = addslashes($_POST['email']);
    $mdp = sha1($_POST['mdp']);
    $ip = $_SERVER['REMOTE_ADDR'];
    
    if ($_POST['mdp'] == $_POST['verifmdp'])
    {
        mysql_query("INSERT INTO vectae_users VALUES('', '" . $email . "', '" . $mdp . "', '" . $ip . "', '" . time() . "')");
    }
    

 


?>


			<h1>Inscription</h1>
			<?php
echo "<p>Félicitations votre compte a été créé.</p>";
}


else {
?>
			<h1>Inscription</h1>
<p><b>Vous devez remplir tous les champs.</b></p>
<p>Votre e-mail sera votre identifiant:</p>

<form method="post" action="">
E-Mail :<input type="text" name="email" class="login"/><br />
Mot de passe :<input type="password" name="mdp"  class="login" /><br />
Mot de passe :<input type="password" name="verifmdp"  class="login"/><br />
<input type="submit" value="S'inscrire" class="buttonok" />
</form>


			<?php }
?>
			
			
		</div>
		
		
