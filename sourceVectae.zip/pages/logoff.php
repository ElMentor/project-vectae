<?php 

$_SESSION = array();
session_destroy();

?>
<script language='javascript'>
document.location.href="index.php";
</script>